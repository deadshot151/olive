import pywhatkit as tk


def surge():
    from data.basic_program.bpc import get_audio
    said = get_audio()
    tk.search(said)
