"""
this is the subsection of oliveHC and in this file
wil be the processing of the events to do with agenda
and everything like wise
"""
import datetime
import json


def evente():
    from data.basic_program.bpc import get_audio
    audio = get_audio().lower()
    if audio == "new event":
        new_event(audio, audio, audio)
    elif audio == "events":
        list_event()
    elif audio == "to do tomorrow":
        list_nextd()
    elif audio == "to do this week":
        list_nextw()
    elif audio == "to do this monte":
        list_nextm()


def list_event():
    with "evetdata.json" as file:
        events = json.load(file)
    return events


def list_nextd():
    with "evetdata.json" as file:
        events = json.load(file)
        _event = sorted(events.Date)
    time1 = datetime.date.today()
    if events.Date + 1 == time1:
        event = events
        return print(event)


def list_nextw():
    with "evetdata.json" as file:
        events = json.load(file)
        _event = sorted(events.Date)
    time1 = datetime.date.today()
    if events.Date + 7 == time1:
        event = events
        return print(event)


def list_nextm():
    with "evetdata.json" as file:
        events = json.load(file)
        _event = sorted(events.Date)
    time1 = datetime.date.today()
    if events.Date + 30 == time1:
        event = events
        return print(event)


def Remainder(Date):
    if Date + str(1) == datetime.date:
        out = "remind"
        return out
    else:
        pass


def new_event(Date, times, label):
    global Re
    while True:
        try:
            try:
                List = {Date, times, label, Re}
                if get_audio() == "yes":
                    Re = "remind"
                    return Re
                else:
                    Re = ""
                    return Re
                with "evetedata.json" as file:
                    json.dump(file, List)

            except:
                List = {Date, times, label}
                with "evetedata.json" as file:
                    json.dump(List, file)
        except:
            return "Error 1.1"
