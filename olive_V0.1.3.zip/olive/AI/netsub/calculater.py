def run():
    from data.basic_program.bpc import get_audio
    var = get_audio()
    a = get_audio()
    b = get_audio()
    sum = {"add", "plus"}
    exs = {"subtract", "mines"}
    dev = {"devoid"}
    mut = {"multiply"}
    if sum == var:
        zum(a, b)
    elif exs == var:
        nun(a, b)
    elif dev == var:
        duf(a, b)
    elif mut == var:
        mul(a, b)
    else:
        pass


def zum(a, b):
    from data.basic_program.bpc import speak
    int(a, b)
    x = a + b
    str(x)
    speak(x)


def nun(a, b):
    from data.basic_program.bpc import speak
    int(a, b)
    x = a - b
    str(x)
    speak(x)


def mul(a, b):
    from data.basic_program.bpc import speak
    int(a, b)
    x = a * b
    str(x)
    speak(x)


def duf(a, b):
    from data.basic_program.bpc import speak
    int(a, b)
    x = a / b
    str(x)
    speak(x)



