def opper():
    from data.basic_program.bpc import get_audio, speak
    event = "events", "upcoming events", "tasks"
    note = "take note", "make note", "note", "remember", "take note"
    sorg = "surge", "google", "surge the internet"
    # simulator = "run simulation", "simulate"
    cal = "calculate"
    audio = get_audio().lower()
    try:
        if audio == cal:
            from AI.netsub import calculater
            return calculater.run()
        elif audio == event:
            from AI.netsub import eventol
            return eventol.evente()
        elif audio == note:
            from AI.netsub import noteol
            return noteol.notepad()
        elif audio == sorg:
            from AI.netsub import surge
            return surge.surge()
        else:
            return speak("no command found")
    except:
        pass



def control():
    from data.basic_program.bpc import get_audio
    
    audinf = get_audio().lower()
    if audinf:
        return opper()
