"""
this is the collection of all the basic programs often joust
in other program files where thai frequently recur
"""


def get_audio():
    import speech_recognition as sr
    # this is the command that makes it cappella zo that olive can listen
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            said = ""
            try:
                said = r.recognize_google(audio)
                print(said)
            except Exception as e:
                print("Exception: " + str(e))
        return said
    except:
        said = "r"
        print("error no microphone")
        return said


def speak(text):
    import playsound
    from gtts import gTTS
    """
    this is the function that gives the app to give verbal information
    to the user
    """
    tts = gTTS(text=text, lang='en')
    filename = 'voice.mp3'
    tts.save(filename)
    playsound.playsound(filename)