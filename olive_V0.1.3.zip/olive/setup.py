from ontwerp.app import MyApp

if __name__ == '__main__':
    MyApp().run()
