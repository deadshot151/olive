from kivy.app import App
from kivy.lang.builder import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from AI.netsub.eventol import Remainder


class LoginWin(Screen):
    from kivy.properties import ObjectProperty
    """
    this is the login window of the app to access olive there is
    a pass word needed to get access to olive if there is not a
    pop-up wil present a message
    """
    password = ObjectProperty(None)

    def loginBtn(self):
        # this is the login button with the shaking's system in it
        if self.password.text == "021512":
            MainWin.current = self.password.text
            MainWin.user = "Yann"
            self.reset()
            sm.current = "main"
        elif self.password.text == "132639":
            MainWin.current = self.password.text
            MainWin.user = "Kenai"
            self.reset()
            sm.current = "main"
        elif self.password.text == "000006":
            MainWin.current = self.password.text
            MainWin.user = "Lode"
            self.reset()
            sm.current = "main"
        elif self.password.text == "041221007":
            MainWin.current = self.password.text
            MainWin.user = "Diego"
            self.reset()
            sm.current = "main"
        else:
            invalidLogin()

    def reset(self):
        self.password.text = ""


class MainWin(Screen):
    from kivy.properties import ObjectProperty
    """
    this is the main window of the app that gives you access to olive
    in this window you can activate en deactivate olive it also presents
    the users name and gives you the option to logout
    """
    current = "main"
    n = ObjectProperty(None)
    o = ObjectProperty(None)

    def on_enter(self, *args):
        if __name__ == '__main__':
            self.n.text = "User name: " + self.user
            speak("good day sir, how can i be of service")

    @staticmethod
    def logOut():
        sm.current = "login"

    @staticmethod
    def BtnActiv():
        from AI import oliveHC
        oliveHC.control()

    def rem(self):
        self.remainder()


class InfoWin(Screen):
    pass


class UserinfoWin(Screen):
    pass


class AgreeWin(Screen):
    pass


class WindowManager(ScreenManager):
    pass


def speak(text):
    from gtts import gTTS
    import playsound
    """
    this is the function that gives the app to give verbal information
    to the user
    """
    tts = gTTS(text=text, lang='en')
    filename = 'voice.mp3'
    tts.save(filename)
    playsound.playsound(filename)


def get_audio():
    import speech_recognition as sr
    # this is the command that makes it cappella zo that olive can listen
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            said = ""
            try:
                said = r.recognize_google(audio)
                print(said)
            except Exception as e:
                print("Exception: " + str(e))
        return said
    except:
        said = "r"
        print("error no microphone")
        return said


def invalidLogin():
    from kivy.uix.popup import Popup
    from kivy.uix.label import Label
    """
    this is the function to present a pup-up massage when given an incorrect
    password is precedent
    """
    pop = Popup(title='Invalid Login',
                content=Label(text='Invalid password.'),
                size_hint=(None, None), size=(400, 400))
    pop.open()


def reminder():
    from kivy.uix.popup import Popup
    from kivy.uix.label import Label
    if "remind" == out:
        pop = Popup(title='remainder',
                    content1=Label(text='remainder event.'),
                    size_hint1=(None, None), size=(400, 400))
        pop.open()
    else:
        pass


kv = Builder.load_file("ayc.kv")
sm = WindowManager()
out = Remainder(Date="")

screens = [LoginWin(name="login"), MainWin(name="main"), InfoWin(name="info"), UserinfoWin(name="appinf"),
           AgreeWin(name="user")]
for Screen in screens:
    sm.add_widget(Screen)

sm.current = "login"


class MyApp(App):
    def build(self):
        return sm
