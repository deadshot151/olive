import playsound
import speech_recognition as sr
from gtts import gTTS


def run():
    var = get_audio()
    a = get_audio()
    b = get_audio()
    sum = {"add", "plus"}
    exs = {"subtract", "mines"}
    dev = {"devoid"}
    mut = {"multiply"}
    if sum == var:
        zum(a, b)
    elif exs == var:
        nun(a, b)
    elif dev == var:
        duf(a, b)
    elif mut == var:
        mul(a, b)
    else:
        pass


def zum(a, b):
    int(a, b)
    x = a + b
    str(x)
    speak(x)


def nun(a, b):
    int(a, b)
    x = a - b
    str(x)
    speak(x)


def mul(a, b):
    int(a, b)
    x = a * b
    str(x)
    speak(x)


def duf(a, b):
    int(a, b)
    x = a / b
    str(x)
    speak(x)


def get_audio():
    # this is the command that makes it cappella zo that olive can listen
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            said = ""
            try:
                said = r.recognize_google(audio)
                print(said)
            except Exception as e:
                print("Exception: " + str(e))
        return said
    except:
        said = "r"
        print("error no microphone")
        return said


def speak(text):
    """
    this is the function that gives the app to give verbal information
    to the user
    """
    tts = gTTS(text=text, lang='en')
    filename = 'voice.mp3'
    tts.save(filename)
    playsound.playsound(filename)
