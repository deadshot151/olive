import pywhatkit as tk
import speech_recognition as sr


def get_audio():
    # this is the command that makes it cappella zo that olive can listen
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            said = ""
            try:
                said = r.recognize_google(audio)
                print(said)
            except Exception as e:
                print("Exception: " + str(e))
        return said
    except:
        said = "r"
        print("error no microphone")
        return said


def surge():
    said = get_audio()
    tk.search(said)
