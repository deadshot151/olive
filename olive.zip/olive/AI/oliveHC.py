def opper():
    event = "events", "upcoming events", "tasks"
    note = "take note", "make note", "note", "remember", "take note"
    sorg = "surge", "google", "surge the internet"
    # simulator = "run simulation", "simulate"
    cal = "calculate"
    audio = get_audio().lower()
    try:
        if audio == cal:
            from AI.netsub import calculater
            return calculater.run()
        elif audio == event:
            from AI.netsub import eventol
            return eventol.evente()
        elif audio == note:
            from AI.netsub import noteol
            return noteol.notepad()
        elif audio == sorg:
            from AI.netsub import surge
            return surge.surge()
        else:
            return speak("no command found")
    except:
        pass


def speak(text):
    import playsound
    from gtts import gTTS
    """
    this is the function that gives the app to give verbal information
    to the user
    """
    tts = gTTS(text=text, lang='en')
    filename = 'voice.mp3'
    tts.save(filename)
    playsound.playsound(filename)


def get_audio():
    import speech_recognition as sr
    # this is the command that makes it cappella zo that olive can listen
    try:
        r = sr.Recognizer()
        with sr.Microphone() as source:
            audio = r.listen(source)
            said = ""
            try:
                said = r.recognize_google(audio)
                print(said)
            except Exception as e:
                print("Exception: " + str(e))
        return said
    except:
        said = "r"
        print("error no microphone")
        return said


def control():
    """
    these are the connections with the subsections of olive
    where her neurol networks are going to be so there is less
    load on olive while she runs that there ar multiple processes
    activate simultaneous
    """
    audinf = get_audio().lower()
    if audinf:
        return opper()
